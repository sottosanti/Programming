

public class HW1 {

	public static void main(String[] args) throws Exception {
		A a = new A();
		B b = new B();
		C c = new C();
		
		a.foo();
		b.foo();
		c.foo();
		a.foo();

	}

}
