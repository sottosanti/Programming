

import javassist.tools.reflect.*;
import javassist.tools.reflect.Metalevel;
import javassist.tools.reflect.Metaobject;

import javassist.*;


public class VerboseMetaobj extends Metaobject {
	
    public VerboseMetaobj(Object self, Object[] args)  throws Throwable {
        super(self, args);
		
	 	ClassPool pool = ClassPool.getDefault();
	    CtClass cc = pool.get(self.getClass().getName());

		CtMethod[] m = cc.getDeclaredMethods();
		

			for (int i=0; i < m.length; i++) {

         		m[i].addLocalVariable("someInt", CtClass.intType);

				m[i].insertBefore("{ someInt = 5; System.out.print(\"Entering: \"); System.out.println(\"" + m[i].getName() + "\"); }");  
				m[i].insertAfter("{System.out.println(someInt); System.out.print(\"Leaving: \"); System.out.println(\"" + m[i].getName() + "\"); }");  

			}
			
			cc.writeFile();
		
    }

    
}
